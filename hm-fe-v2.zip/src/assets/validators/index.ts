export * from './email.validator';
export * from './equalPasswords.validator';
export * from './amount.valdator';