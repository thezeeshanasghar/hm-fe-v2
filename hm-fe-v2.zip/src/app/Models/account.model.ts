export class AccountModel {

    public Id: number;
    public Number: string;
    public Name: string;
    public MobileNumber: string;
    public CNIC: string;
    public Address: string;
    public Created: string;
    public Balance: number;
    public Image:string;
    public constructor() {}
}