export class CarOwner{
    AccountId:number[]
}