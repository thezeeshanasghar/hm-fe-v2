import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-car-purchase',
  templateUrl: './edit-car-purchase.component.html',
  styleUrls: ['./edit-car-purchase.component.css']
})
export class EditCarPurchaseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
